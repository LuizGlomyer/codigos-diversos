#ifndef UNIONFIND_HPP_INCLUDED
#define UNIONFIND_HPP_INCLUDED

template<typename T>
class UnionFind{
public:
    UnionFind();
    ~UnionFind();
    void makeSet();
    void Union();
    void findSet();
private:

};


#endif // UNIONFIND_HPP_INCLUDED
